ace.define("ace/snippets/nix",["require","exports","module"],function(e,t,n){"use strict";t.snippetText=undefined,t.scope="nix"});                (function() {
                    ace.require(["ace/snippets/nix"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            