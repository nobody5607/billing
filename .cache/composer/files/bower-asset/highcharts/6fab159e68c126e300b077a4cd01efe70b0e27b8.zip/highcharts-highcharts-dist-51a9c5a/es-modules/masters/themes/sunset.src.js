/**
 * @license Highcharts JS v7.1.3 (2019-08-14)
 * @module highcharts/themes/sunset
 * @requires highcharts
 *
 * (c) 2009-2019 Highsoft AS
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/sunset.js';
