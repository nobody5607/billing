/**
 * @license Highcharts JS v7.1.3 (2019-08-14)
 * @module highcharts/themes/skies
 * @requires highcharts
 *
 * (c) 2009-2019 Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../themes/skies.js';
